import React from 'react';

function Food() {
  const foods = ['Sushi', 'Thai Green Curry', 'Grass-fed Steak'];

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h2>Food Suggestions</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {foods.map((food, idx) => (
          <li key={idx} style={{ margin: '0.5rem 0' }}>{food}</li>
        ))}
      </ul>
    </div>
  );
}

export default Food;