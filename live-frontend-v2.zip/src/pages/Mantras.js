import React from 'react';

function Mantras() {
  const mantras = [
    'With our thoughts we make the world.',
    'You are safe. You are loved. Be you, you’ll be fine.',
    'Breathe in peace, breathe out love.'
  ];

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h2>Daily Mantras</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {mantras.map((m, idx) => (
          <li key={idx} style={{ margin: '0.5rem 0' }}>{m}</li>
        ))}
      </ul>
    </div>
  );
}

export default Mantras;