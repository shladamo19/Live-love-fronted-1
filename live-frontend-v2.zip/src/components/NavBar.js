import React from 'react';
import { Link } from 'react-router-dom';

const linkStyle = {
  color: '#fff',
  textDecoration: 'none',
  margin: '0 0.5rem'
};

function NavBar() {
  return (
    <nav style={{ padding: '1rem', background: '#222', display: 'flex', justifyContent: 'center' }}>
      <Link style={linkStyle} to="/">Dashboard</Link>
      <Link style={linkStyle} to="/music">Music</Link>
      <Link style={linkStyle} to="/food">Food</Link>
      <Link style={linkStyle} to="/mantras">Mantras</Link>
      <Link style={linkStyle} to="/energy">Energy</Link>
    </nav>
  );
}

export default NavBar;