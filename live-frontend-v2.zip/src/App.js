import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import Dashboard from './pages/Dashboard';
import Music from './pages/Music';
import Food from './pages/Food';
import Mantras from './pages/Mantras';
import Energy from './pages/Energy';

function App() {
  return (
    <Router>
      <NavBar />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/music" element={<Music />} />
        <Route path="/food" element={<Food />} />
        <Route path="/mantras" element={<Mantras />} />
        <Route path="/energy" element={<Energy />} />
      </Routes>
    </Router>
  );
}

export default App;