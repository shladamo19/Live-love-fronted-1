import React from 'react';

function Music() {
  const sampleSongs = [
    { title: 'Weightless', artist: 'Marconi Union' },
    { title: 'Electric Feel', artist: 'MGMT' },
    { title: 'Golden Hour', artist: 'JVKE' }
  ];

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h2>Music Recommendations</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {sampleSongs.map((song, idx) => (
          <li key={idx} style={{ margin: '0.5rem 0' }}>
            {song.title} – {song.artist}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Music;