import React, { useState, useEffect } from 'react';
import { moodColors } from '../theme';

function Dashboard({ setBg }) {
  const [energy, setEnergy] = useState('Loading...');
  const [mood, setMood] = useState('');
  const [targetMood, setTargetMood] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => {
      setEnergy('High Vibrations 🌟');
      setMessage('You are safe. You are loved. Be you, you’ll be fine.');
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    const desired = targetMood || mood;
    const color = moodColors[desired.toLowerCase()] || moodColors.default;
    setBg(color);
    alert(`Shifting vibes to ${desired}. Background adjusted!`);
    setMood('');
    setTargetMood('');
  };

  return (
    <div style={{ textAlign:'center', padding:'2rem', minHeight:'calc(100vh - 64px)' }}>
      <h2>Live / Love Energy Dashboard</h2>
      <p style={{ fontSize:'1.2rem', margin:'1rem 0' }}>{energy}</p>
      <blockquote style={{ fontStyle:'italic', color:'#eee' }}>{message}</blockquote>

      <form onSubmit={handleSubmit} style={{ marginTop:'2rem' }}>
        <div style={{ marginBottom:'1rem' }}>
          <label>
            Current mood:<br />
            <input value={mood} onChange={e=>setMood(e.target.value)} placeholder="e.g., calm" style={{ padding:'0.5rem', width:'200px' }}/>
          </label>
        </div>
        <div style={{ marginBottom:'1rem' }}>
          <label>
            Desired mood (optional):<br />
            <input value={targetMood} onChange={e=>setTargetMood(e.target.value)} placeholder="e.g., happy" style={{ padding:'0.5rem', width:'200px' }}/>
          </label>
        </div>
        <button type="submit" style={{ padding:'0.6rem 1.2rem', background:'#4caf50', border:'none', borderRadius:'4px', color:'#fff', cursor:'pointer' }}>
          Shift Vibes
        </button>
      </form>
    </div>
  );
}

export default Dashboard;