import React, { useEffect, useState } from 'react';

function Energy() {
  const [forecast, setForecast] = useState('Loading cosmic forecast...');

  useEffect(() => {
    // Placeholder: replace with real API call to backend
    const timer = setTimeout(() => {
      setForecast('Cosmic energy surge expected tomorrow ✨');
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h2>Energy Forecast</h2>
      <p>{forecast}</p>
    </div>
  );
}

export default Energy;