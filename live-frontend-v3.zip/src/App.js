import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import NavBar from './components/NavBar';
import Dashboard from './pages/Dashboard';
import Music from './pages/Music';
import Food from './pages/Food';
import Mantras from './pages/Mantras';
import Energy from './pages/Energy';
import { moodColors } from './theme';

function Wrapper({ setBg }) {
  const location = useLocation();
  useEffect(() => {
    // default background reset on route change
    document.body.style.background = moodColors.default;
    setBg(moodColors.default);
  }, [location, setBg]);
  return (
    <Routes>
      <Route path="/" element={<Dashboard setBg={setBg} />} />
      <Route path="/music" element={<Music />} />
      <Route path="/food" element={<Food />} />
      <Route path="/mantras" element={<Mantras />} />
      <Route path="/energy" element={<Energy />} />
    </Routes>
  );
}

function App() {
  const [bg, setBg] = useState(moodColors.default);

  useEffect(() => {
    document.body.style.background = bg;
  }, [bg]);

  return (
    <Router>
      <NavBar />
      <Wrapper setBg={setBg} />
    </Router>
  );
}

export default App;