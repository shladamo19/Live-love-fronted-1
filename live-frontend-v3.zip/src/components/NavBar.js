import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import Logo from '../../public/assets/logo.svg';

const linkStyle = {
  color: '#fff',
  margin: '0 0.7rem',
  fontWeight: 500
};

function NavBar() {
  const { pathname } = useLocation();
  return (
    <nav style={{ display:'flex',alignItems:'center', justifyContent:'center', background:'#00000050', padding:'0.5rem 1rem', backdropFilter:'blur(6px)' }}>
      <img src={Logo} alt="Live Love Logo" style={{ height:'32px', marginRight:'1rem' }}/>
      <div>
        <Link style={{ ...linkStyle, opacity: pathname==='/'?1:0.7 }} to="/">Dashboard</Link>
        <Link style={{ ...linkStyle, opacity: pathname==='/music'?1:0.7 }} to="/music">Music</Link>
        <Link style={{ ...linkStyle, opacity: pathname==='/food'?1:0.7 }} to="/food">Food</Link>
        <Link style={{ ...linkStyle, opacity: pathname==='/mantras'?1:0.7 }} to="/mantras">Mantras</Link>
        <Link style={{ ...linkStyle, opacity: pathname==='/energy'?1:0.7 }} to="/energy">Energy</Link>
      </div>
    </nav>
  );
}

export default NavBar;