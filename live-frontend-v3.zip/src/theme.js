export const moodColors = {
  happy: '#ffeb3b',
  calm: '#00bcd4',
  focused: '#ff9800',
  loving: '#e91e63',
  sad: '#3f51b5',
  angry: '#f44336',
  default: '#673ab7'
};